package dev.yours4nty.ultimatebackpacks.utils;

import dev.yours4nty.ultimatebackpacks.storage.SharedBackpackStorageProvider;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.UUID;

public class SharedBackpackStorage {

    private static SharedBackpackStorageProvider provider;

    public static void init(SharedBackpackStorageProvider storageProvider) {
        provider = storageProvider;
    }

    public static void create(String name, UUID owner) {
        provider.create(name, owner);
    }

    public static boolean exists(String name) {
        return provider.exists(name);
    }

    public static void delete(String name) {
        provider.delete(name);
    }

    public static void transferOwnership(String name, UUID newOwner) {
        provider.transferOwnership(name, newOwner);
    }

    public static UUID getOwner(String name) {
        return provider.getOwner(name);
    }

    public static List<UUID> getMembers(String name) {
        return provider.getMembers(name);
    }

    public static void addMember(String name, UUID uuid) {
        provider.addMember(name, uuid);
    }

    public static void removeMember(String name, UUID uuid) {
        provider.removeMember(name, uuid);
    }

    public static List<String> getSharedBackpacks(UUID uuid) {
        return provider.getSharedBackpacks(uuid);
    }

    public static ItemStack[] getContents(String name) {
        return provider.getContents(name);
    }

    public static void saveContents(String name, ItemStack[] contents) {
        provider.saveContents(name, contents);
    }

    public static void shutdown() {
        provider.shutdown();
    }

    public static List<String> getSharedBackpacksAsMember(UUID playerUUID) {
        File folder = new File("plugins/UltimateBackpacks/sharedBackpacks");
        if (!folder.exists() || !folder.isDirectory()) return Collections.emptyList();

        List<String> result = new ArrayList<>();

        for (File file : Objects.requireNonNull(folder.listFiles((dir, name) -> name.endsWith(".yml")))) {
            FileConfiguration config = YamlConfiguration.loadConfiguration(file);
            String owner = config.getString("owner");
            List<String> members = config.getStringList("members");

            if (!playerUUID.toString().equals(owner) && members.contains(playerUUID.toString())) {
                result.add(file.getName().replace(".yml", ""));
            }
        }

        return result;
    }

}
