package dev.yours4nty.ultimatebackpacks.utils;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.profile.PlayerProfile;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.UUID;

public class ItemBuilder {

    public static ItemStack createBackpackItem() {
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) skull.getItemMeta();

        try {
            URL url = new URL("http://textures.minecraft.net/texture/b9b18b02453db1ba2564c1f9c967fdaa4f3f8f95d697265d4bde6620d68deeab");
            PlayerProfile profile = Bukkit.createPlayerProfile(UUID.randomUUID());
            profile.getTextures().setSkin(url);
            meta.setOwnerProfile(profile);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        String name = MessageHandler.get("item-backpack-name");
        meta.setDisplayName(org.bukkit.ChatColor.translateAlternateColorCodes('&', name));
        skull.setItemMeta(meta);
        return skull;
    }
}
