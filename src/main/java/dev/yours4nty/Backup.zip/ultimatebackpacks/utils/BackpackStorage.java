package dev.yours4nty.ultimatebackpacks.utils;

import dev.yours4nty.ultimatebackpacks.UltimateBackpacks;
import dev.yours4nty.ultimatebackpacks.storage.BackpackStorageProvider;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.*;

public class BackpackStorage {

    private static final Map<UUID, Map<Integer, Inventory>> backpacks = new HashMap<>();
    private static BackpackStorageProvider provider;

    public static void init(BackpackStorageProvider storageProvider) {
        provider = storageProvider;
    }

    public static Inventory getBackpack(UUID uuid, int index) {
        backpacks.putIfAbsent(uuid, new HashMap<>());
        Map<Integer, Inventory> playerBackpacks = backpacks.get(uuid);

        if (!playerBackpacks.containsKey(index)) {
            String title = ChatColor.translateAlternateColorCodes('&',
                    MessageHandler.get("backpack-inventory-title").replace("%number%", String.valueOf(index))
            );

            Inventory inv = Bukkit.createInventory(null, 54, title);
            Inventory loaded = provider.loadBackpack(uuid, index);
            if (loaded != null) {
                inv.setContents(loaded.getContents());
            }

            playerBackpacks.put(index, inv);
        }

        return playerBackpacks.get(index);
    }

    public static void saveBackpack(Player player, int index) {
        UUID uuid = player.getUniqueId();
        Inventory inv = getBackpack(uuid, index);
        provider.saveBackpack(uuid, index, inv);
    }

    public static void saveAllBackpacks(UUID uuid) {
        Map<Integer, Inventory> playerBackpacks = backpacks.get(uuid);
        if (playerBackpacks == null) return;

        for (Map.Entry<Integer, Inventory> entry : playerBackpacks.entrySet()) {
            int index = entry.getKey();
            provider.saveBackpack(uuid, index, entry.getValue());
        }
    }

    public static void openBackpack(Player player, int index) {
        Inventory inv = getBackpack(player.getUniqueId(), index);
        player.openInventory(inv);
    }

    public static void openBackpack(Player viewer, UUID targetUUID, int index) {
        Inventory inv = getBackpack(targetUUID, index);
        viewer.openInventory(inv);
    }

    public static int getMaxBackpacks(Player player) {
        return provider.getMaxBackpacks(player);
    }
}
