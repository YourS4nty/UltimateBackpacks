package dev.yours4nty.ultimatebackpacks.utils;

import org.bukkit.Bukkit;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class InventorySerializer {

    public static byte[] serialize(Inventory inventory) {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
             BukkitObjectOutputStream oos = new BukkitObjectOutputStream(baos)) {
            oos.writeInt(inventory.getSize());
            oos.writeObject(inventory.getContents());
            return baos.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Inventory deserialize(byte[] data) {
        try (ByteArrayInputStream bais = new ByteArrayInputStream(data);
             BukkitObjectInputStream ois = new BukkitObjectInputStream(bais)) {
            int size = ois.readInt();
            ItemStack[] items = (ItemStack[]) ois.readObject();
            Inventory inventory = Bukkit.createInventory(null, size);
            inventory.setContents(items);
            return inventory;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return Bukkit.createInventory(null, 54); // Fallback
        }
    }
}
