package dev.yours4nty.ultimatebackpacks.utils;

import dev.yours4nty.ultimatebackpacks.UltimateBackpacks;
import org.bukkit.World;

import java.util.List;

public class WorldUtils {

    private static List<String> blacklistedWorlds;

    public static void loadWorldBlacklist() {
        blacklistedWorlds = UltimateBackpacks.getInstance().getConfig().getStringList("WorldSettings.BlacklistWorlds");
    }

    public static boolean isBlacklisted(World world) {
        return blacklistedWorlds.contains(world.getName());
    }
}
