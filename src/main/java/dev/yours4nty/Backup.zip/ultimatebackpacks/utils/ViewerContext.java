package dev.yours4nty.ultimatebackpacks.utils;

import java.util.HashMap;
import java.util.UUID;

public class ViewerContext {

    private static final HashMap<UUID, UUID> viewerToTarget = new HashMap<>();

    public static void set(UUID viewer, UUID target) {
        viewerToTarget.put(viewer, target);
    }

    public static UUID get(UUID viewer) {
        return viewerToTarget.get(viewer);
    }

    public static void clear(UUID viewer) {
        viewerToTarget.remove(viewer);
    }
}
