package dev.yours4nty.ultimatebackpacks.storage;

import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.UUID;

public interface SharedBackpackStorageProvider {

    void create(String name, UUID owner);

    boolean exists(String name);

    void delete(String name);

    void transferOwnership(String name, UUID newOwner);

    UUID getOwner(String name);

    List<UUID> getMembers(String name);

    void addMember(String name, UUID uuid);

    void removeMember(String name, UUID uuid);

    List<String> getSharedBackpacks(UUID member);

    ItemStack[] getContents(String name);

    void saveContents(String name, ItemStack[] contents);

    default void shutdown() {}
}
