package dev.yours4nty.ultimatebackpacks.listeners;

import dev.yours4nty.ultimatebackpacks.utils.BackpackStorage;
import dev.yours4nty.ultimatebackpacks.BackpackGUI;
import dev.yours4nty.ultimatebackpacks.utils.MessageHandler;
import dev.yours4nty.ultimatebackpacks.utils.Config;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.ChatColor;

public class InventoryListener implements Listener {

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        BackpackGUI.handleClick(event);

        // Si se permite mochila dentro de mochila, no hacemos ninguna validación
        if (Config.allowBackpackInsideBackpack) return;

        Inventory clickedInventory = event.getClickedInventory();
        Inventory topInventory = event.getView().getTopInventory();
        ItemStack currentItem = event.getCurrentItem();
        ItemStack cursor = event.getCursor();

        if (clickedInventory == null || topInventory == null) return;

        // Solo aplicamos la lógica si se está interactuando con una mochila personalizada
        if (!isBackpackInventory(topInventory)) return;

        // Intentando colocar una mochila con el cursor
        if (cursor != null && isBackpackItem(cursor)) {
            event.setCancelled(true);
            player.sendMessage(MessageHandler.get("backpack-inside-error"));
            return;
        }

        // Click sobre un item ya dentro del inventario
        if (currentItem != null && isBackpackItem(currentItem)) {
            event.setCancelled(true);
            player.sendMessage(MessageHandler.get("backpack-inside-error-current"));
            return;
        }

        // Movimiento con tecla numérica
        if (event.getClick().isKeyboardClick() && event.getHotbarButton() >= 0) {
            ItemStack hotbarItem = player.getInventory().getItem(event.getHotbarButton());
            if (isBackpackItem(hotbarItem)) {
                event.setCancelled(true);
                player.sendMessage(MessageHandler.get("backpack-inside-error-current"));
            }
        }

        // Shift-click hacia el backpack
        if (event.getAction().toString().contains("MOVE_TO_OTHER") && isBackpackItem(currentItem)) {
            if (clickedInventory.equals(player.getInventory())) {
                event.setCancelled(true);
                player.sendMessage(MessageHandler.get("backpack-inside-error"));
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;

        Inventory closedInventory = event.getInventory();
        String title = event.getView().getTitle();

        String localizedPrefix = ChatColor.stripColor(
                ChatColor.translateAlternateColorCodes('&', MessageHandler.get("backpack-inventory-title").replace("%number%", ""))
        ).toLowerCase();

        if (title != null && ChatColor.stripColor(title).toLowerCase().startsWith(localizedPrefix)) {
            try {
                String numberStr = ChatColor.stripColor(title).replaceAll("[^0-9]", "");
                int index = Integer.parseInt(numberStr.trim());
                if (index >= 1 && index <= 10) {
                    BackpackStorage.saveBackpack(player, index);
                }
            } catch (NumberFormatException ignored) {}
        }
    }

    private boolean isBackpackItem(ItemStack item) {
        if (item == null || item.getType() != Material.PLAYER_HEAD || !item.hasItemMeta()) return false;

        String template = MessageHandler.get("item-backpack-name"); // Ej: "Backpack" sin número
        String expectedPrefix = ChatColor.stripColor(ChatColor.translateAlternateColorCodes('&', template)).toLowerCase();

        String displayName = item.getItemMeta().getDisplayName();
        if (displayName == null) return false;

        String strippedDisplayName = ChatColor.stripColor(displayName).toLowerCase();

        return strippedDisplayName.startsWith(expectedPrefix);
    }

    private boolean isBackpackInventory(Inventory inv) {
        if (inv == null || inv.getViewers().isEmpty()) return false;

        Player viewer = (Player) inv.getViewers().get(0);
        String title = ChatColor.stripColor(viewer.getOpenInventory().getTitle()).toLowerCase();

        String personal = ChatColor.stripColor(
                ChatColor.translateAlternateColorCodes('&', MessageHandler.get("backpack-inventory-title").replace("%number%", ""))
        ).toLowerCase();

        String shared = ChatColor.stripColor(
                ChatColor.translateAlternateColorCodes('&', MessageHandler.get("shared-backpack-title").replace("%name%", ""))
        ).toLowerCase();

        return title.startsWith(personal) || title.startsWith(shared);
    }
}
