package dev.yours4nty.ultimatebackpacks.listeners;

import dev.yours4nty.ultimatebackpacks.utils.Config;
import dev.yours4nty.ultimatebackpacks.utils.MessageHandler;
import dev.yours4nty.ultimatebackpacks.utils.SharedBackpackStorage;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SharedBackpackListener implements Listener {

    @EventHandler
    public void onClickSharedBackpack(InventoryClickEvent event) {
        if (!Config.allowSharedBackpacks) return;
        if (!(event.getWhoClicked() instanceof Player player)) return;

        String guiTitle = ChatColor.stripColor(event.getView().getTitle());
        String expectedTitle = ChatColor.stripColor(MessageHandler.get("shared-title"));

        // Cancel click only in shared backpack selector GUI
        if (guiTitle.equals(expectedTitle)) {
            event.setCancelled(true);
        }

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;

        String displayName = ChatColor.stripColor(clicked.getItemMeta().getDisplayName());
        String template = ChatColor.stripColor(MessageHandler.get("shared-slot-name")); // Ej: "Shared Backpack #%name%"
        String regex = "^" + Pattern.quote(template).replace("%name%", "\\E(.+)\\Q") + "$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(displayName);

        if (!matcher.matches()) return;
        String name = matcher.group(1).trim();

        File file = new File("plugins/UltimateBackpacks/sharedBackpacks", name + ".yml");
        if (!file.exists()) {
            player.sendMessage(MessageHandler.get("shared-backpack-does-not-exist"));
            return;
        }

        FileConfiguration config = YamlConfiguration.loadConfiguration(file);
        List<String> members = config.getStringList("members");

        if (!members.contains(player.getUniqueId().toString())) {
            player.sendMessage(MessageHandler.get("shared-backpack-not-member"));
            return;
        }

        Inventory sharedInv = Bukkit.createInventory(null, 54,
                ChatColor.translateAlternateColorCodes('&',
                        MessageHandler.get("shared-backpack-title").replace("%name%", name)));

        sharedInv.setContents(SharedBackpackStorage.getContents(name));
        player.openInventory(sharedInv);
    }

    @EventHandler
    public void onCloseSharedBackpack(InventoryCloseEvent event) {
        if (!Config.allowSharedBackpacks) {
            System.out.println("[DEBUG] Shared backpacks are disabled in config.");
            return;
        }

        String title = ChatColor.stripColor(event.getView().getTitle());
        String template = ChatColor.stripColor(MessageHandler.get("shared-backpack-title")); // Ej: "Shared Backpack: %name%"
        String regex = "^" + Pattern.quote(template).replace("%name%", "\\E(.+)\\Q") + "$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(title);

        if (matcher.matches()) {
            String name = matcher.group(1).trim();
            Inventory topInventory = event.getView().getTopInventory();
            ItemStack[] contents = topInventory.getContents();
            int nonNull = 0;
            for (ItemStack i : contents) if (i != null) nonNull++;
            SharedBackpackStorage.saveContents(name, contents);
        } else {
            System.out.println("[DEBUG] Inventory title did not match shared-backpack-title pattern.");
        }
    }


}
