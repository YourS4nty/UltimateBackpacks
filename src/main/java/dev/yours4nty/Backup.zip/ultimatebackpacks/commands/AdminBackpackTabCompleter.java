package dev.yours4nty.ultimatebackpacks.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.io.File;

public class AdminBackpackTabCompleter implements TabCompleter {
    @Override
    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("ultimatebackpacks.admin")) return Collections.emptyList();

        if (args.length == 1) {
            return Arrays.asList("reload", "view", "viewshared").stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .collect(Collectors.toList());
        }

        if (args.length == 2 && args[0].equalsIgnoreCase("view")) {
            return Bukkit.getOnlinePlayers().stream()
                    .map(p -> p.getName())
                    .filter(name -> name.toLowerCase().startsWith(args[1].toLowerCase()))
                    .collect(Collectors.toList());
        }

        if (args.length == 3 && args[0].equalsIgnoreCase("view")) {
            return IntStream.rangeClosed(1, 10)
                    .mapToObj(String::valueOf)
                    .filter(num -> num.startsWith(args[2]))
                    .collect(Collectors.toList());
        }

        if (args.length == 2 && args[0].equalsIgnoreCase("viewshared")) {
            File dir = new File("plugins/UltimateBackpacks/sharedBackpacks");
            if (!dir.exists()) return Collections.emptyList();

            return Arrays.stream(dir.listFiles((d, name) -> name.endsWith(".yml")))
                    .map(f -> f.getName().replace(".yml", ""))
                    .filter(name -> name.toLowerCase().startsWith(args[1].toLowerCase()))
                    .collect(Collectors.toList());
        }

        return Collections.emptyList();
    }
}
