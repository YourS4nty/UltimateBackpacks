package dev.yours4nty.ultimatebackpacks.commands;

import dev.yours4nty.ultimatebackpacks.utils.BackpackStorage;
import dev.yours4nty.ultimatebackpacks.BackpackGUI;
import dev.yours4nty.ultimatebackpacks.utils.WorldUtils;
import dev.yours4nty.ultimatebackpacks.utils.MessageHandler;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class OpenBPCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(MessageHandler.get("ingame-only"));
            return true;
        }

        if (WorldUtils.isBlacklisted(player.getWorld())) {
            player.sendMessage(MessageHandler.get("disabled-in-world"));
            return true;
        }

        int backpackIndex = 1;

        if (args.length > 0) {
            try {
                backpackIndex = Integer.parseInt(args[0]);
            } catch (NumberFormatException e) {
                player.sendMessage(MessageHandler.get("usage-openbp"));
                return true;
            }

            if (backpackIndex < 1 || backpackIndex > 10) {
                player.sendMessage(MessageHandler.get("backpack-number-out-of-range"));
                return true;
            }
        }

        int limit = getBackpackLimit(player);
        if (backpackIndex > limit) {
            player.sendMessage(MessageHandler.get("no-permission-backpack"));
            return true;
        }

        //BackpackStorage.openBackpack(player, backpackIndex);
        BackpackGUI.openSelector(player);
        return true;
    }

    private int getBackpackLimit(Player player) {
        for (int i = 10; i >= 0; i--) {
            if (player.hasPermission("ultimatebackpacks.limit." + i)) {
                return i;
            }
        }
        return 0;
    }
}
