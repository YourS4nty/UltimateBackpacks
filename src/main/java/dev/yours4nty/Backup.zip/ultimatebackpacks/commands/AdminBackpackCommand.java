package dev.yours4nty.ultimatebackpacks.commands;

import dev.yours4nty.ultimatebackpacks.BackpackGUI;
import dev.yours4nty.ultimatebackpacks.UltimateBackpacks;
import dev.yours4nty.ultimatebackpacks.utils.BackpackStorage;
import dev.yours4nty.ultimatebackpacks.utils.Config;
import dev.yours4nty.ultimatebackpacks.utils.MessageHandler;
import dev.yours4nty.ultimatebackpacks.utils.WorldUtils;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class AdminBackpackCommand implements CommandExecutor {
    private final UltimateBackpacks plugin;

    public AdminBackpackCommand(UltimateBackpacks plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("ultimatebackpacks.admin")) {
            sender.sendMessage(MessageHandler.get("no-permission"));
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage("§dUltimateBackpacks - Admin Help:");
            sender.sendMessage("§b/ubp reload §7- " + MessageHandler.get("admin-help-reload"));
            sender.sendMessage("§b/ubp view <player> [number] §7- " + MessageHandler.get("admin-help-view"));
            return true;
        }

        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            plugin.reloadConfig();
            Config.load(plugin.getConfig());
            MessageHandler.loadMessages();

            String decorated = "§5[UltimateBackpacks] §a" + MessageHandler.get("reload-success");
            sender.sendMessage(decorated);
            Bukkit.getConsoleSender().sendMessage(decorated);
            return true;
        }

        if (args.length < 3 || !args[0].equalsIgnoreCase("view")) {
            sender.sendMessage(MessageHandler.get("usage-view"));
            return true;
        }

        if (args.length >= 2 && args[0].equalsIgnoreCase("viewshared")) {
            String name = args[1];
            File file = new File("plugins/UltimateBackpacks/sharedBackpacks", name + ".yml");

            if (!file.exists()) {
                sender.sendMessage(MessageHandler.get("shared-backpack-does-not-exist"));
                return true;
            }

            if (!(sender instanceof Player viewer)) {
                sender.sendMessage(MessageHandler.get("ingame-only"));
                return true;
            }

            if (WorldUtils.isBlacklisted(viewer.getWorld())) {
                viewer.sendMessage(MessageHandler.get("disabled-in-world"));
                return true;
            }

            Inventory sharedInv = Bukkit.createInventory(null, 54,
                    ChatColor.translateAlternateColorCodes('&',
                            MessageHandler.get("shared-backpack-title").replace("%name%", name)));

            sharedInv.setContents(SharedBackpackStorage.getContents(name));
            viewer.openInventory(sharedInv);
            return true;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        if (target == null || (!target.hasPlayedBefore() && !target.isOnline())) {
            sender.sendMessage(MessageHandler.get("player-not-found"));
            return true;
        }

        if (!(sender instanceof Player viewer)) {
            sender.sendMessage(MessageHandler.get("ingame-only"));
            return true;
        }

        if (WorldUtils.isBlacklisted(viewer.getWorld())) {
            viewer.sendMessage(MessageHandler.get("disabled-in-world"));
            return true;
        }

        try {
            int index = Integer.parseInt(args[2]);
            if (index < 1 || index > 10) {
                viewer.sendMessage(MessageHandler.get("number-out-of-range"));
                return true;
            }

            BackpackStorage.openBackpack(viewer, target.getUniqueId(), index);
        } catch (NumberFormatException e) {
            viewer.sendMessage(MessageHandler.get("invalid-number"));
        }

        return true;
    }
}
